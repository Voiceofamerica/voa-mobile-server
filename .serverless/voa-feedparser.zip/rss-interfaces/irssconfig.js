var feedUrl = "http://www.rferl.org/mobapp/config.xml";
// Feed Parameters
// None
//# sourceMappingURL=irssconfig.js.map