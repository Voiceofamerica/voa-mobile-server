"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArticlesFeedUrl = 'https://www.rferl.org/mobapp/articles.xml';
//# sourceMappingURL=irssarticle.js.map