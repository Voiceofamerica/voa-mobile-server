"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var feedUrl = "http://www.rferl.org/mobapp/zones.xml";
//# sourceMappingURL=irsszone.js.map