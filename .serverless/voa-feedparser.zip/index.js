"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var handler_1 = require("./handler");
handler_1.articles({}, {}, function (res) {
    console.log(res);
});
//# sourceMappingURL=index.js.map